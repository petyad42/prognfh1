#ifndef MAIN_H_INCLUDED
#define MAIN_H_INCLUDED

enum {ABLAKX=1400 };
enum {ABLAKY=1000 };

extern int sejtmeret;



#endif // MAIN_H_INCLUDED
