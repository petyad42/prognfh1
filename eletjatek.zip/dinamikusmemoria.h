#ifndef DINAMIKUSMEMORIA_H_INCLUDED
#define DINAMIKUSMEMORIA_H_INCLUDED
int** lefoglal(int tmeret);
void felszabadit(int** tomb,int meret);
int** atmeretez(int **tomb,int ujmeret,int meret);



#endif // DINAMIKUSMEMORIA_H_INCLUDED
