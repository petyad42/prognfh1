#ifndef SDLGRAFIKA_H_INCLUDED
#define SDLGRAFIKA_H_INCLUDED
void sdl_init(int szeles, int magas, SDL_Window **pwindow, SDL_Renderer **prenderer);
Uint32 idozit(Uint32 ms, void *param);

#endif // SDLGRAFIKA_H_INCLUDED
